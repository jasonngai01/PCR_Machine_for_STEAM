#include "Relay.h"

Relay::Relay(const int pin) : Switchable(pin)
{
    
}
